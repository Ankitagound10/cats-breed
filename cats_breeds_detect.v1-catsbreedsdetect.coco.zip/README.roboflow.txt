
cats_breeds_detect - v1 catsbreedsdetect
==============================

This dataset was exported via roboflow.ai on July 1, 2021 at 8:49 AM GMT

It includes 10 images.
Experiment are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


